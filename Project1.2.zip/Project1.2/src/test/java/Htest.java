import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.internal.WebElementToJsonConverter;

import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.fail;

public class Htest {
    private WebDriver driver;
    private String baseUrl;
    private boolean acceptNextAlert = true;
    private StringBuffer verificationErrors = new StringBuffer();
    private final String BASE_URL = ("http://localhost/tabulka.php");

    @Before
    public void setUp () {driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

    }

    @Test
    public void test () {
        driver.get(BASE_URL);
        Assert.assertEquals("1", driver.findElement(By.cssSelector("td")).getText());
        List<WebElement> rows = driver.findElements(By.xpath("//table//tbody/tr"));
        for (int i = 1; i < rows.size() + 1; i++) {
            try {
                Assert.assertEquals(String.valueOf(i), driver.findElement(By.xpath("//tr[" + i + "]/td")).getText());
            } catch (Error e) {
                verificationErrors.append(e.toString());
                System.out.println("overovanie tabulky hotovo");

            }
        }
    }
    @After
    public void tearDown () throws Exception {
        driver.quit();
        String verificationErrorString = verificationErrors.toString();
        if (! "".equals(verificationErrorString)) {
            fail(verificationErrorString);
        }

    }
}
