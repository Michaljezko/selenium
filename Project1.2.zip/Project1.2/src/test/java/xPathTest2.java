import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class xPathTest2 {
    private WebDriver driver;
    private final String BASE_URL = ("http://localhost/registracia.php");



    @Before
    public void setUp () {
        driver = new FirefoxDriver();
    }
    @Test
    public void test () {
        driver.get(BASE_URL);
        driver.findElement(By.xpath("//formP/div[1]/input")).sendKeys("brano@peres");
        driver.findElement(By.xpath("//form/div[2]/input")).sendKeys("brano");
        driver.findElement(By.xpath("//form/div[3]/input")).sendKeys("peres");

    }
    @After
    public void tearDown () {

    }

}
