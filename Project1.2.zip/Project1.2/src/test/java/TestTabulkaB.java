import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestTabulkaB {
    private WebDriver driver;
    private final String BASE_URL = "http://localhost/tabulka.php";

    @Before
    public void setUp () {driver = new FirefoxDriver();}

    @Test
    public void test () {
        driver.get(BASE_URL);
        System.out.println(driver.findElement(By.xpath("//table/tbody/tr[last()]/td[1]")).getText());

        //in xpath - //table/tbody/tr[last()] it markd last line,   //table/tbody/tr[last()]/td[1] first element in last line//
        int rows = Integer.parseInt(driver.findElement(By.xpath("//table/tbody/tr[last()]/td[1]")).getText());
        // int rows = and copy driver, then use integer.parseInt - it convert text to number (first element in last line is some number example 78//
        // but IDEA takes from web always text so 78 is text) Integer.parsenInt convert it//
        for (int i = 1; i < rows+1; i++ ) {
            driver.findElement(By.xpath("//table/tbody/tr[" + i + "]"));
            // + i + , space between//
            System.out.println(driver.findElement(By.xpath("//table/tbody/tr[" + i + "]")).getText());
            //test failed, when i have i = 0 so I have to change i = 0 to i = 1 and rows+1 (row + without space)//
            System.out.println(driver.findElement(By.xpath("//table/tbody/tr[" + i + "]/td[3]")).getText());
            //if I want see only surname I have to add /td[3]//
            Assert.assertFalse(driver.findElement(By.xpath("//table/tbody/tr[" + i + "]/td[3]")).getText().isEmpty());
        }

    }

    @After
    public void tearDown () {

    }
}
