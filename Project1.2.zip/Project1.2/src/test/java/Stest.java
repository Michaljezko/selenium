import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

public class Stest {
    private WebDriver driver;
    private final String BASE_URL = ("http://localhost/registracia.php");

    @Before
    public void setUp () {driver = new FirefoxDriver();}
    @Test
    public void testMissingAllImpputs () throws InterruptedException, IOException {
        driver.manage().window().maximize();
        driver.get(BASE_URL);
        driver.findElement(By.id("checkbox")).click();
        driver.findElement(By.xpath("//button[@class='btn btn-success btn-lg btn-block']")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//div[contains(@class,'alert alert-danger')]")).isDisplayed());

        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        FileHandler.copy(scrFile, new File("C://cmp\\screenshot.png"));
    }
    @Test
    public void testMissingPassword() {
        driver.manage().window().maximize();
        driver.get(BASE_URL);
        driver.findElement(By.id("checkbox")).click();
        driver.findElement(By.name("email")).sendKeys("brano@gmail.com");
        driver.findElement(By.name("name")).sendKeys("Brano");
        driver.findElement(By.name("surname")).sendKeys("Peres");

        driver.findElement(By.xpath("//button[@class='btn btn-success btn-lg btn-block']")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//div[contains(@class,'alert alert-danger')]")).isDisplayed());
    }
    @Test
    public void testMissMatchPassword () {
        driver.manage().window().maximize();
        driver.get(BASE_URL);
        driver.findElement(By.id("checkbox")).click();
        driver.findElement(By.name("email")).sendKeys("brano@gmail.com");
        driver.findElement(By.name("name")).sendKeys("Brano");
        driver.findElement(By.name("surname")).sendKeys("Peres");

        driver.findElement(By.name("password")).sendKeys("bludcislo1");
        driver.findElement(By.name("password-repeat")).sendKeys("bludcislo123456");

        driver.findElement(By.xpath("//button[@class='btn btn-success btn-lg btn-block']")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//div[contains(@class,'alert alert-danger')]")).isDisplayed());
    }
    @Test
    public void testMissingRobotCheckbox () {
        driver.manage().window().maximize();
        driver.get(BASE_URL);

        driver.findElement(By.id("checkbox")).click();
        driver.findElement(By.name("email")).sendKeys("brano@gmail.com");
        driver.findElement(By.name("name")).sendKeys("Brano");
        driver.findElement(By.name("surname")).sendKeys("Peres");

        driver.findElement(By.name("password")).sendKeys("bludcislo1");
        driver.findElement(By.name("password-repeat")).sendKeys("bludcislo1g");

        driver.findElement(By.xpath("//button[@class='btn btn-success btn-lg btn-block']")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//div[contains(@class,'alert alert-danger')]")).isDisplayed());
    }

    @Test
    public void testSuccessFullRegistration () throws InterruptedException {
        driver.manage().window().maximize();
        driver.get(BASE_URL);


        driver.findElement(By.name("email")).sendKeys("brano@gmail.com");
        driver.findElement(By.name("name")).sendKeys("Brano");
        driver.findElement(By.name("surname")).sendKeys("Peres");

        driver.findElement(By.name("password")).sendKeys("bludcislo1");
        driver.findElement(By.name("password-repeat")).sendKeys("bludcislo1");

//<groupId>junit</groupId>
//      <artifactId>junit</artifactId>
//      <version>4.13.2</version>
//      <scope>test</scope>
//        <dependency>
//      <groupId>junit</groupId>
//      <artifactId>junit</artifactId>
//      <version>3.8.1</version>
//      <scope>test</scope>
//    </dependency>

        driver.findElement(By.id("checkbox")).click();
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//div[contains(@class,'alert-success')]")).isDisplayed());
    }

    @After
    public void tearDown () {
        if (this.driver != null) {
            this.driver.quit();
        }



    }
}
