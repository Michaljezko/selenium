import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class StestB {
    private WebDriver driver;
    private final String BASE_URL = ("http://localhost/kalkulacka.php");

    @Before
    public void setUp () {
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        driver.get(BASE_URL);
    }
    @Test
    public void testsSum () throws InterruptedException, IOException {

        driver.findElement(By.id("firstInput")).sendKeys("9");
        driver.findElement(By.id("secondInput")).sendKeys("4");
        driver.findElement(By.id("count")).click();
        System.out.println(driver.findElement(By.id("result")).getText());
        Assert.assertEquals("13", driver.findElement(By.id("result")).getText());

        driver.findElement(By.id("firstInput")).clear();
        driver.findElement(By.id("firstInput")).sendKeys("7");
        driver.findElement(By.id("secondInput")).clear();
        driver.findElement(By.id("secondInput")).sendKeys("3");
        driver.findElement(By.id("count")).click();
        System.out.println(driver.findElement(By.id("result")).getText());
        Assert.assertEquals("10", driver.findElement(By.id("result")).getText());

        driver.findElement(By.id("firstInput")).clear();
        driver.findElement(By.id("firstInput")).sendKeys("9");
        driver.findElement(By.id("secondInput")).clear();
        driver.findElement(By.id("secondInput")).sendKeys("26");
        driver.findElement(By.id("count")).click();
        System.out.println(driver.findElement(By.id("result")).getText());
        Assert.assertEquals("35", driver.findElement(By.id("result")).getText());
    }

    @Test
    public void testsDeduct () throws InterruptedException, IOException {
        driver.findElement(By.id("firstInput")).clear();
        driver.findElement(By.id("firstInput")).sendKeys("9");
        driver.findElement(By.id("secondInput")).clear();
        driver.findElement(By.id("secondInput")).sendKeys("26");
        driver.findElement(By.id("deduct")).click();
        System.out.println(driver.findElement(By.id("result")).getText());
        Assert.assertEquals("-17", driver.findElement(By.id("result")).getText());

    }
    @Test
    public void testsReset () throws InterruptedException, IOException {

    }
    @Test
    public void testsInvalidInputs () throws InterruptedException, IOException {

    }

    @After
    public void tearDown () {
//        if (this.driver != null) {
//            this.driver.quit();
//        }



    }
}
