import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import java.util.List;

public class ExperimentForSelenideA extends mainTest {
    @Before
    public void openBaseUrl() { driver.get(getBASE_URL() + "tabulka.php"); }

    @Test
    public void tableTest() {
        List<WebElement> rows = driver.findElements(By.xpath("//table//tbody//tr"));

        for (WebElement row : rows) {
            if (row.getText().contains("Peter")){
                ((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px solid red'", row);
            }
        }
    }

    @After
    public void tearDown() {

    }

}
