import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class mainTest {
    public String getBASE_URL() {
        return BASE_URL;
    }

    private final String BASE_URL = "http://localhost/";
    public WebDriver driver;



    @Before
    public void setUp() {
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
    }

    @After
    public void tearDown () {
        if (this.driver != null) {
            this.driver.quit();
        }
    }

}
