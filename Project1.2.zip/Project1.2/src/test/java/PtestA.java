import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;

public class PtestA {
    private WebDriver driver;
    private final String BASE_URL = ("http://localhost/semafor.php");
    private String hexColor;

    @Before
    public void setUp () {driver = new ChromeDriver();}
    @Test
    public void test () throws InterruptedException {
        String expectedRed = "rgba(205, 58, 63, 1)";
        String expectedGreen = "rgba(10, 129, 0, 1)";
        driver.get(BASE_URL);
        WebElement traficlight = driver.findElement(By.xpath("//div[contains(@class,'light')]"));
        String actualRedColor = traficlight.getCssValue("background-color");

        hexColor = Color.fromString(traficlight.getCssValue("background-color")).asHex();
        System.out.println(hexColor);
        Assert.assertEquals(expectedRed,actualRedColor);

        //#cd3a3f

        Actions actions = new Actions(driver);
        actions.moveToElement(traficlight).build().perform();
        String actualGreenColor = traficlight.getCssValue("background-color");{
            hexColor = Color.fromString(traficlight.getCssValue("background-color")).asHex();
            System.out.println(hexColor);
            Assert.assertEquals(expectedGreen,actualGreenColor);
            //#0a8100
        }

        //rgba(10, 129, 0,1)   rgba(205, 58, 63,1) #cd3a3f
    }
    @After
    public void tearDown () {
        //driver.close();
        //driver.quit();

    }
}
