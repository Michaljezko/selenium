import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.Color;

import java.util.List;

public class KtestA {
    private WebDriver driver;
    private final String BASE_URL = ("http://localhost/stroopeffect.php");

    @Before
    public void setUp () {driver = new FirefoxDriver();}
    @Test
    public void test () throws InterruptedException {
        driver.get(BASE_URL);
        List<WebElement> titles = driver.findElements(By.xpath("//div[contains(@class,'colours')]/h1"));
        String hexColor = null;
        for (WebElement title : titles) {
            System.out.println(title.getCssValue("color"));
            hexColor = Color.fromString(title.getCssValue("color")).asHex();
            System.out.println(title.getCssValue("font-size"));
            System.out.println(title.getText());
            System.out.println(driver.findElement(By.xpath("//div[contains(@class,'colours')]/h1")).getCssValue("color"));
            System.out.println(hexColor);
        }



    }
    @After
    public void tearDown () {

    }
}
