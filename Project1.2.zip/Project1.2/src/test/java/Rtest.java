import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Rtest {
    private WebDriver driver;
    private final String BASE_URL = ("http://localhost/semafor.php");

    @Before
    public void setUp () {driver = new ChromeDriver();}
    @Test
    public void test () throws InterruptedException {
        String expectedGreen = "rgba(10, 129, 0, 1)";
        String expectedRed = "rgba(205, 58, 63, 1)";
        String expectedOrange = "rgba(191, 111, 7, 1)";
        driver.get(BASE_URL);
        WebElement traficlight = driver.findElement(By.xpath("//div[contains(@class,'light')]"));
        String actualRedColor = traficlight.getCssValue("background-color");
        Assert.assertEquals(expectedRed,actualRedColor);

        Actions actions = new Actions(driver);
        actions.moveToElement(traficlight).build().perform();

        String actualGreenColor = traficlight.getCssValue("background-color");
        Assert.assertEquals(expectedGreen,actualGreenColor);


        actions.clickAndHold(traficlight).build().perform();
        String actualOrange = traficlight.getCssValue("background-color");
        Assert.assertEquals(expectedOrange,actualOrange);


        //rgba(10, 129, 0,1)   rgba(205, 58, 63,1) rgba(10, 129, 0,1) hover, focus
    }
    @After
    public void tearDown () {
        driver.close();
        driver.quit();

    }
}
