import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestNsixD {
    private WebDriver driver;
    private final String BASE_URL = ("http://localhost/clickmebaby.php");

    @Before
    public void setUp () {driver = new FirefoxDriver();}
    @Test
    public void test () {
        driver.get(BASE_URL);
        Assert.assertEquals("inicialny pocet klikov", "0", driver.findElement(By.id("clicks")).getText() );
        for (int i = 0; i < 10; i++) {
        driver.findElement(By.id("clickMe")).click();
        }
    }
    @After
    public void tearDown () {

    }
}
