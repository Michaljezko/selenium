import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.io.IOException;

public class StestC extends mainTest {

    @Before
    public void openBaseUrl() { driver.get(getBASE_URL() + "kalkulacka.php"); }
    @Test
    public void testSum() {
        checkSum("5", "2", "7");
        checkSum("7", "2", "9");
        checkSum("3", "24", "27");
        checkSum("-5", "2", "-3");
        checkSum("115", "2", "117");
        checkSum("55", "12", "67");
    }
    private void checkSum (String firstInput, String secondInput, String expected) {
        driver.findElement(By.id("firstInput")).clear();
        driver.findElement(By.id("firstInput")).sendKeys(firstInput);
        driver.findElement(By.id("secondInput")).clear();
        driver.findElement(By.id("secondInput")).sendKeys(secondInput);
        driver.findElement(By.id("count")).click();
        System.out.println(driver.findElement(By.id("result")).getText());
        Assert.assertEquals(expected, driver.findElement(By.id("result")).getText());
    }
    @Test
    public void testsDeduct ()  {
        checkDeduct("5", "2", "3");
        checkDeduct("15", "2", "13");
        checkDeduct("55", "2", "53");
        checkDeduct("12", "2", "10");
        checkDeduct("45", "22", "23");
        checkDeduct("17", "2", "15");
    }
    private void checkDeduct (String firstInput, String secondInput, String expected) {

        driver.findElement(By.id("firstInput")).clear();
        driver.findElement(By.id("firstInput")).sendKeys(firstInput);
        driver.findElement(By.id("secondInput")).clear();
        driver.findElement(By.id("secondInput")).sendKeys(secondInput);
        driver.findElement(By.id("deduct")).click();
        System.out.println(driver.findElement(By.id("result")).getText());
        Assert.assertEquals(expected, driver.findElement(By.id("result")).getText());
    }
    @Test
    public void checkReset () {
        driver.findElement(By.id("firstInput")).clear();
        driver.findElement(By.id("firstInput")).sendKeys("5");
        driver.findElement(By.id("secondInput")).clear();
        driver.findElement(By.id("secondInput")).sendKeys("4");

        driver.findElement(By.id("count")).click();
        driver.findElement(By.id("reset")).click();
        Assert.assertTrue(driver.findElement(By.id("firstInput")).getAttribute("value").isEmpty());
        Assert.assertTrue(driver.findElement(By.id("secondInput")).getAttribute("value").isEmpty());
        Assert.assertTrue(driver.findElement(By.id("result")).getText().isEmpty());
    }
    @Test
    public void testsInvalidInputs ()  {
        driver.findElement(By.id("firstInput")).clear();
        driver.findElement(By.id("firstInput")).sendKeys("blud1");
        driver.findElement(By.id("secondInput")).clear();
        driver.findElement(By.id("secondInput")).sendKeys("blud2");

        driver.findElement(By.id("count")).click();

        Assert.assertTrue(driver.findElement(By.xpath("//div[input[@id='firstInput']]"))
                .getAttribute("class").contains("has-error"));
        Assert.assertTrue(driver.findElement(By.xpath("//div[input[@id='secondInput']]"))
                .getAttribute("class").contains("has-error"));
    }

    @After
    public void tearDown () {
        if (this.driver != null) {
            this.driver.quit();
        }
    }
}


