import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;

import java.io.File;
import java.io.IOException;

public class RtestCdonald {
    private WebDriver driver;
    private final String BASE_URL = ("http://localhost/moveme.php");

    @Before
    public void setUp () {driver = new FirefoxDriver();}
    @Test
    public void test () throws InterruptedException, IOException {
        driver.manage().window().maximize();
        driver.get(BASE_URL);
        WebElement donald = driver.findElement(By.id("donald"));
        Actions actions = new Actions(driver);
        //actions.clickAndHold(donald).moveByOffset(1000,0).release().build().perform();
       // for (int i = 0; i < 500; i++) {}
            actions.clickAndHold(donald).moveByOffset(1000, 0).release().build().perform();
            //Thread.sleep(200);



        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        FileHandler.copy(scrFile, new File("C://cmp\\screenshot.png"));

    }
    @After
    public void tearDown () {
        //driver.close();
        //driver.quit();

    }
}
