import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class RtestBdonald {
    private WebDriver driver;
    private final String BASE_URL = ("http://localhost/moveme.php");

    @Before
    public void setUp () {driver = new ChromeDriver();}
    @Test
    public void test () throws InterruptedException {
        driver.manage().window().maximize();
        driver.get(BASE_URL);
        WebElement donald = driver.findElement(By.id("donald"));
        WebElement tree = driver.findElement(By.id("tree"));
        Actions actions = new Actions(driver);
        actions.dragAndDrop(donald,tree).build().perform();
        System.out.println(driver.findElement(By.xpath("//div[contains(@class,'success text-center')]/h2")).getText());

        WebElement expectedTitle = (driver.findElement(By.xpath("//div[contains(@class,'success text-center')]/h2")));
//        Assert.assertTrue(driver.findElement(By.xpath("//div[contains(@class,'success text-center')]/h2")).isDisplayed());
//        Assert.assertEquals("HOOO HOOOOO !!!!",driver.findElement(By.xpath("//div[contains(@class,'success text-center')]/h2")).getText());
        // change expectedTitle insted of long driver, if something is change in web, I don't have to change it on meny places, but only one
        Assert.assertTrue(expectedTitle.isDisplayed());
        Assert.assertEquals("HOOO HOOOOO !!!!",expectedTitle.getText());

    }
    @After
    public void tearDown () {
        //driver.close();
        //driver.quit();

    }
}
