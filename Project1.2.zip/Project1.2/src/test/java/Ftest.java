import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Ftest extends mainTest {

    @Before
    public void openBaseUrl() { driver.get(getBASE_URL() + "zenaalebomuz.php"); }

    @Test
    public void test () {

        driver.findElement(By.xpath("//input[@value='wurst']")).click();

        System.out.println(driver.findElement(By.xpath("//h1[@class='description text-center']")).getText());
        Assert.assertTrue(driver.findElement(By.xpath("//input[@value='wurst']")).isSelected());
        driver.findElement(By.xpath("//input[@value='wurst']")).isSelected();
        Assert.assertFalse(driver.findElement(By.xpath("//input[@value='conchita']")).isSelected());
        driver.findElement(By.xpath("//input[@value='conchita']")).isSelected();
        System.out.println(driver.findElement(By.xpath("//input[@value='conchita']")).isSelected());
        System.out.println(driver.findElement(By.xpath("//input[@value='wurst']")).isSelected());

    }

}
