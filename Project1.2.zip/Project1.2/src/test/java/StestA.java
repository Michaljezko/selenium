import org.junit.After;

import org.junit.Before;
import org.junit.Test;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class StestA {
    private WebDriver driver;
    private final String BASE_URL = ("http://localhost/registracia.php");
    private String validEmail = "brano@gmail.com";
    private String validName = "Brano";
    private String validSurname = "Peres";

    @Before
    public void setUp () {
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        driver.get(BASE_URL);

    }
    @Test
    public void testMissingAllImpputs () throws InterruptedException, IOException {

        driver.findElement(By.id("checkbox")).click();
        driver.findElement(By.xpath("//button[@class='btn btn-success btn-lg btn-block']")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//div[contains(@class,'alert alert-danger')]")).isDisplayed());

        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        FileHandler.copy(scrFile, new File("C://cmp\\screenshot.png"));
    }
    @Test
    public void testMissingPassword() {
        driver.findElement(By.id("checkbox")).click();
        driver.findElement(By.name("email")).sendKeys(validEmail);
        driver.findElement(By.name("name")).sendKeys(validName);
        driver.findElement(By.name("surname")).sendKeys(validSurname);

        driver.findElement(By.xpath("//button[@class='btn btn-success btn-lg btn-block']")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//div[contains(@class,'alert alert-danger')]")).isDisplayed());
    }
    @Test
    public void testMissMatchPassword () {
        driver.findElement(By.id("checkbox")).click();
        driver.findElement(By.name("email")).sendKeys(validEmail);
        driver.findElement(By.name("name")).sendKeys(validName);
        driver.findElement(By.name("surname")).sendKeys(validSurname);

        driver.findElement(By.name("password")).sendKeys("bludcislo1");
        driver.findElement(By.name("password-repeat")).sendKeys("bludcislo123456");

        driver.findElement(By.xpath("//button[@class='btn btn-success btn-lg btn-block']")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//div[contains(@class,'alert alert-danger')]")).isDisplayed());
    }
    @Test
    public void testMissingRobotCheckbox () {

        driver.findElement(By.id("checkbox")).click();
        driver.findElement(By.name("email")).sendKeys(validEmail);
        driver.findElement(By.name("name")).sendKeys(validName);
        driver.findElement(By.name("surname")).sendKeys(validSurname);

        driver.findElement(By.name("password")).sendKeys("bludcislo1");
        driver.findElement(By.name("password-repeat")).sendKeys("bludcislo1g");

        driver.findElement(By.xpath("//button[@class='btn btn-success btn-lg btn-block']")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//div[contains(@class,'alert alert-danger')]")).isDisplayed());
    }

    @Test
    public void testSuccessFullRegistration () throws InterruptedException {

        driver.findElement(By.name("email")).sendKeys(validEmail);
        driver.findElement(By.name("name")).sendKeys(validName);
        driver.findElement(By.name("surname")).sendKeys(validSurname);

        driver.findElement(By.name("password")).sendKeys("bludcislo1");
        driver.findElement(By.name("password-repeat")).sendKeys("bludcislo1");

        driver.findElement(By.id("checkbox")).click();
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//div[contains(@class,'alert-success')]")).isDisplayed());
    }
    @Test
    public void testInputBorder() {
        String expectedClass = "has-error";
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        List<WebElement> formDivs = driver.findElements(By.xpath("//div[input]"));
        for (WebElement formDiv : formDivs) {
            //System.out.println(formDiv.getAttribute("class").contains("has-error"));
            Assert.assertTrue(formDiv.getAttribute("class").contains("has-error"));
        }
        //driver.findElement(By.xpath("//div[input[@name='email']]")).getAttribute("class");
        Assert.assertTrue(driver.findElement(By.xpath("//div[label[input[@id='checkbox']]]"))
                .getAttribute("class").contains("has-error"));
    }

    @After
    public void tearDown () {
//        if (this.driver != null) {
//            this.driver.quit();
//        }



    }
}
