import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class TestSelectB {
    private WebDriver driver;
    private final String BASE_URL = "http://localhost/vybersi.php";

    @Before
    public void setUp () {driver = new FirefoxDriver();}

    @Test
    public void test () {
        driver.get(BASE_URL);
        new Select(driver.findElement(By.className("form-control"))).selectByVisibleText("Squirtle");
        //selectByVisibleText - copy text between >and<//
        driver.findElement(By.xpath("//div[2]/h3")).getText();
                // I want confirm, that title contain word Squirtle, so I use findBy element by xpath,//
        // but i will not use this (/html/body/div/div[2]/h3) but I short it to //div[2]/h3//
        System.out.println(driver.findElement(By.xpath("//div[2]/h3")).getText());
        //system.out.print and copy before line//
        Assert.assertTrue("Squirtle sa v texte nenachadza",driver.findElement(By.xpath("//div[2]/h3")).getText().contains("Squirtle"));
        //Asseert.true and copy 22. line, but assert true answer to question true or false, so I have to add contains and text(Squirtle)//
        //I  add message (Squirtle sa v texte nenachadza) onli as a helf, it show it in dawn console, when test fail//
        Assert.assertFalse(driver.findElement(By.xpath("//div[2]/h3")).getText().contains("Pikatchu"));
    }

    @After
    public void tearDown () {

    }
}
