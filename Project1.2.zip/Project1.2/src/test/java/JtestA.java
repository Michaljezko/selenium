import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class JtestA {
    private WebDriver driver;
    private final String BASE_URL = ("http://localhost");

    @Before
    public void setUp () {driver = new FirefoxDriver();}
    @Test
    public void test () throws InterruptedException {
        String expectedClass = "active";
        driver.get(BASE_URL+"/vybersi.php");
        Assert.assertTrue(driver.findElement(By.xpath("//li[a/@href='vybersi.php']"))
                .getAttribute("class").contains(expectedClass));

        driver.get(BASE_URL+"/tabulka.php");
        Assert.assertTrue(driver.findElement(By.xpath("//li[a/@href='tabulka.php']"))
                .getAttribute("class").contains(expectedClass));

        driver.get(BASE_URL+"/zjavenie.php");
        Assert.assertTrue(driver.findElement(By.xpath("//li[a/@href='zjavenie.php']"))
                .getAttribute("class").contains(expectedClass));

    }
    @After
    public void tearDown () {

    }
}
