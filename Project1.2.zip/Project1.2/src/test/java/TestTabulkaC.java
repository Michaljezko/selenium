import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.List;

public class TestTabulkaC {
    private WebDriver driver;
    private final String BASE_URL = ("http://localhost/tabulka.php");

    @Before
    public void setUp () {driver = new FirefoxDriver();}
    @Test
    public void test () {
        driver.get(BASE_URL);
        List<WebElement> rows = driver.findElements(By.xpath("//table/tbody/tr"));
        //System.out.println(rows);//

        for (WebElement row : rows) {
            //System.out.println(row.getText());//
            //row.findElement(By.xpath("./td[3]")).getText();//
            //you have to add . dot and only one / //
            //System.out.println(row.findElement(By.xpath("./td[3]")).getText());//
            Assert.assertFalse(row.findElement(By.xpath("./td[3]")).getText().isEmpty());
        }

            



    }
    @After
    public void tearDown () {

    }
}
